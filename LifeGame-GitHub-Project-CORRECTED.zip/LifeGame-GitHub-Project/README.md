# LifeGame Android project

This project wraps the LifeGame HTML app in an Android WebView.

- App name: LifeGame
- Application ID: com.lifegame.app
- Portrait mode
- JavaScript enabled
- DOM storage/localStorage enabled

Note: the current HTML loads React, ReactDOM, and Babel from unpkg, so the first version requires internet access. Those dependencies can be bundled later for a fully offline APK.
