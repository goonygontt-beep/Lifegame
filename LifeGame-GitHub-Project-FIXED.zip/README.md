# LifeGame Android Project

This project packages the LifeGame single-file HTML app inside an Android WebView.

## Build

Use Gradle with Android Gradle Plugin 8.7.3 and Java 17. The GitHub Actions workflow can build the debug APK.

Note: the HTML currently loads React, ReactDOM and Babel from unpkg, so the app needs internet access on first/runtime use. LocalStorage is enabled for saved LifeGame data.
