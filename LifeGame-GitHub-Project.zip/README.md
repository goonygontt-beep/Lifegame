# LifeGame Android APK

Android WebView wrapper + GitHub Actions build.

## Phone-only build

1. Create a GitHub repository.
2. Upload the files in this project.
3. Open **Actions**.
4. Run **Build LifeGame APK**.
5. Download the `LifeGame-debug-apk` artifact from the completed workflow.
6. Extract `app-debug.apk` and install it.

## Important

Replace `app/src/main/assets/index.html` with your complete LifeGame HTML before building.

Your current HTML loads React, ReactDOM and Babel from unpkg.com, so those dependencies need internet access. The Android wrapper itself is configured correctly for JavaScript and localStorage.
